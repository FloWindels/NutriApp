--
-- PostgreSQL database dump
--

\restrict GnR2hezGlF1kPgsCv1atahcQEHGKWwXc8tdOEQfhq3xSLIbDvRRsiMZfgo85cum

-- Dumped from database version 14.24 (Ubuntu 14.24-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.24 (Ubuntu 14.24-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: daily_targets; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.daily_targets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    calories smallint NOT NULL,
    proteins smallint NOT NULL,
    carbs smallint NOT NULL,
    fat smallint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.daily_targets OWNER TO mavioh;

--
-- Name: daily_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.daily_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.daily_targets_id_seq OWNER TO mavioh;

--
-- Name: daily_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.daily_targets_id_seq OWNED BY public.daily_targets.id;


--
-- Name: exercises; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.exercises (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    category character varying(16) NOT NULL,
    muscle_group character varying(32) NOT NULL,
    equipment character varying(32) NOT NULL,
    level character varying(16) NOT NULL,
    met numeric(4,1) NOT NULL,
    default_sets smallint,
    default_reps smallint,
    default_duration_sec smallint,
    instructions text NOT NULL,
    contraindications json,
    is_public boolean DEFAULT true NOT NULL,
    created_by_user_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.exercises OWNER TO mavioh;

--
-- Name: exercises_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.exercises_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercises_id_seq OWNER TO mavioh;

--
-- Name: exercises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.exercises_id_seq OWNED BY public.exercises.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO mavioh;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO mavioh;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: food; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.food (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    barcode character varying(255),
    name character varying(255) NOT NULL,
    brand character varying(255),
    image_url text,
    calories numeric(8,2),
    fat numeric(8,2),
    carbs numeric(8,2),
    proteins numeric(8,2),
    source_type character varying(255) DEFAULT 'manual'::character varying NOT NULL,
    created_by_user_id bigint,
    serving_size_g numeric(8,2),
    serving_label character varying(64),
    category character varying(100),
    allergens json,
    fiber numeric(8,2),
    sugar numeric(8,2),
    salt numeric(8,2),
    density_g_per_ml numeric(5,3),
    per_unit character varying(8) DEFAULT '100g'::character varying NOT NULL,
    source_fetched_at timestamp(0) without time zone,
    off_last_checked_at timestamp(0) without time zone,
    is_verified boolean DEFAULT false NOT NULL
);


ALTER TABLE public.food OWNER TO mavioh;

--
-- Name: food_favorites; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.food_favorites (
    user_id bigint NOT NULL,
    food_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.food_favorites OWNER TO mavioh;

--
-- Name: food_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.food_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.food_id_seq OWNER TO mavioh;

--
-- Name: food_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.food_id_seq OWNED BY public.food.id;


--
-- Name: household_members; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.household_members (
    id bigint NOT NULL,
    household_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role character varying(16) DEFAULT 'membre'::character varying NOT NULL,
    share_profile boolean DEFAULT true NOT NULL,
    joined_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.household_members OWNER TO mavioh;

--
-- Name: household_members_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.household_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.household_members_id_seq OWNER TO mavioh;

--
-- Name: household_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.household_members_id_seq OWNED BY public.household_members.id;


--
-- Name: households; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.households (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    owner_id bigint NOT NULL,
    invite_code character varying(8) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.households OWNER TO mavioh;

--
-- Name: households_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.households_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.households_id_seq OWNER TO mavioh;

--
-- Name: households_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.households_id_seq OWNED BY public.households.id;


--
-- Name: meal_items; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.meal_items (
    id bigint NOT NULL,
    meal_id bigint NOT NULL,
    food_id bigint,
    recipe_id bigint,
    stock_item_id bigint,
    source_type character varying(16) NOT NULL,
    label character varying(255) NOT NULL,
    quantity numeric(8,2) NOT NULL,
    unit character varying(16) NOT NULL,
    grams_equivalent numeric(8,2),
    calories numeric(8,2) NOT NULL,
    proteins numeric(8,2) NOT NULL,
    carbs numeric(8,2) NOT NULL,
    fat numeric(8,2) NOT NULL,
    fiber numeric(8,2),
    sugar numeric(8,2),
    salt numeric(8,2),
    ref_basis character varying(16) NOT NULL,
    ref_calories numeric(8,2),
    ref_proteins numeric(8,2),
    ref_carbs numeric(8,2),
    ref_fat numeric(8,2),
    ref_fiber numeric(8,2),
    ref_sugar numeric(8,2),
    ref_salt numeric(8,2),
    ref_serving_size_g numeric(8,2),
    is_estimate boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.meal_items OWNER TO mavioh;

--
-- Name: meal_items_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.meal_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meal_items_id_seq OWNER TO mavioh;

--
-- Name: meal_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.meal_items_id_seq OWNED BY public.meal_items.id;


--
-- Name: meal_plans; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.meal_plans (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    household_id bigint,
    date date NOT NULL,
    meal_type character varying(32) NOT NULL,
    recipe_id bigint,
    food_id bigint,
    title character varying(255) NOT NULL,
    servings numeric(4,1) DEFAULT '1'::numeric NOT NULL,
    notes text,
    status character varying(16) DEFAULT 'prevu'::character varying NOT NULL,
    meal_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.meal_plans OWNER TO mavioh;

--
-- Name: meal_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.meal_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meal_plans_id_seq OWNER TO mavioh;

--
-- Name: meal_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.meal_plans_id_seq OWNED BY public.meal_plans.id;


--
-- Name: meals; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.meals (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    type character varying(32) NOT NULL,
    name character varying(255),
    consumed_at timestamp(0) without time zone,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.meals OWNER TO mavioh;

--
-- Name: meals_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.meals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meals_id_seq OWNER TO mavioh;

--
-- Name: meals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.meals_id_seq OWNED BY public.meals.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO mavioh;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO mavioh;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: notification_reads; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.notification_reads (
    user_id bigint NOT NULL,
    key character varying(64) NOT NULL,
    read_at timestamp(0) without time zone
);


ALTER TABLE public.notification_reads OWNER TO mavioh;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO mavioh;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO mavioh;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO mavioh;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.profiles (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    user_id bigint,
    poids numeric(6,2),
    taille numeric(6,2),
    age smallint,
    sexe character varying(20),
    objectif character varying(100),
    niveau_activite character varying(100),
    poids_a_perdre_kg numeric(6,2),
    delai_objectif_semaines smallint,
    bien_etre character varying(20),
    calories_cibles smallint,
    proteines_cibles smallint,
    glucides_cibles smallint,
    lipides_cibles smallint,
    regime_alimentaire character varying(100),
    poids_souhaite_kg numeric(6,2),
    delai_objectif_jours smallint,
    objectif_type character varying(20),
    allergenes json,
    aliments_exclus json,
    preferences json,
    sport_niveau character varying(16),
    sport_objectif character varying(32),
    sport_materiel json,
    sport_temps_dispo_min smallint,
    sport_jours_semaine smallint,
    sport_lieu character varying(16),
    sport_zones_a_eviter json,
    sport_focus json,
    sport_notes text,
    sport_coef_calories smallint DEFAULT '100'::smallint NOT NULL,
    objectif_calcul_auto boolean DEFAULT true NOT NULL,
    objectif_date_debut date,
    objectif_date_fin date,
    poids_reference numeric(6,2),
    cibles_calculees_le date,
    situation_particuliere character varying(32) DEFAULT 'aucune'::character varying NOT NULL,
    consentement_parental boolean DEFAULT false NOT NULL
);


ALTER TABLE public.profiles OWNER TO mavioh;

--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.profiles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.profiles_id_seq OWNER TO mavioh;

--
-- Name: profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.profiles_id_seq OWNED BY public.profiles.id;


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.recipes (
    id bigint NOT NULL,
    created_by_user_id bigint,
    title character varying(255) NOT NULL,
    description text,
    prep_time_minutes smallint,
    calories numeric(8,2) NOT NULL,
    image_url text,
    ingredients json,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    servings numeric(4,1) DEFAULT '1'::numeric NOT NULL,
    proteins numeric(8,2),
    carbs numeric(8,2),
    fat numeric(8,2),
    tags json,
    meal_types json,
    is_estimate boolean DEFAULT false NOT NULL
);


ALTER TABLE public.recipes OWNER TO mavioh;

--
-- Name: recipes_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.recipes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recipes_id_seq OWNER TO mavioh;

--
-- Name: recipes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.recipes_id_seq OWNED BY public.recipes.id;


--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.recommendations (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    type character varying(32) NOT NULL,
    dedupe_key character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    factors json,
    actions json,
    priority smallint DEFAULT '3'::smallint NOT NULL,
    status character varying(16) DEFAULT 'new'::character varying NOT NULL,
    is_estimate boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.recommendations OWNER TO mavioh;

--
-- Name: recommendations_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.recommendations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recommendations_id_seq OWNER TO mavioh;

--
-- Name: recommendations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.recommendations_id_seq OWNED BY public.recommendations.id;


--
-- Name: shopping_items; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.shopping_items (
    id bigint NOT NULL,
    user_id bigint,
    household_id bigint,
    food_id bigint,
    label character varying(255) NOT NULL,
    quantity numeric(8,2),
    unit character varying(16),
    checked boolean DEFAULT false NOT NULL,
    source character varying(16) DEFAULT 'manuel'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.shopping_items OWNER TO mavioh;

--
-- Name: shopping_items_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.shopping_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shopping_items_id_seq OWNER TO mavioh;

--
-- Name: shopping_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.shopping_items_id_seq OWNED BY public.shopping_items.id;


--
-- Name: sport_plans; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.sport_plans (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    sport_id bigint,
    sport_name character varying(80) NOT NULL,
    planned_duration_min smallint NOT NULL,
    planned_at time(0) without time zone,
    lieu character varying(16),
    notes text,
    status character varying(16) DEFAULT 'prevu'::character varying NOT NULL,
    session_id bigint,
    recurrence_id character varying(36),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.sport_plans OWNER TO mavioh;

--
-- Name: sport_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.sport_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sport_plans_id_seq OWNER TO mavioh;

--
-- Name: sport_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.sport_plans_id_seq OWNED BY public.sport_plans.id;


--
-- Name: sports; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.sports (
    id bigint NOT NULL,
    name character varying(80) NOT NULL,
    slug character varying(100) NOT NULL,
    category character varying(32) NOT NULL,
    met_faible numeric(4,1) NOT NULL,
    met_moderee numeric(4,1) NOT NULL,
    met_elevee numeric(4,1) NOT NULL,
    icon character varying(32),
    is_public boolean DEFAULT true NOT NULL,
    created_by_user_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.sports OWNER TO mavioh;

--
-- Name: sports_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.sports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sports_id_seq OWNER TO mavioh;

--
-- Name: sports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.sports_id_seq OWNED BY public.sports.id;


--
-- Name: stock_items; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.stock_items (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    stock_id bigint,
    food_id bigint,
    food_name character varying(255),
    food_barcode character varying(32),
    food_brand character varying(255),
    quantity numeric(8,2) DEFAULT '1'::numeric NOT NULL,
    unit character varying(32) DEFAULT 'unite'::character varying NOT NULL,
    expires_at date,
    min_quantity numeric(8,2),
    opened_at date,
    depleted_at timestamp(0) without time zone,
    expiry_kind character varying(8) DEFAULT 'dlc'::character varying NOT NULL
);


ALTER TABLE public.stock_items OWNER TO mavioh;

--
-- Name: stock_items_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.stock_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stock_items_id_seq OWNER TO mavioh;

--
-- Name: stock_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.stock_items_id_seq OWNED BY public.stock_items.id;


--
-- Name: stocks; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.stocks (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    user_id bigint,
    name character varying(255) DEFAULT 'Frigo'::character varying NOT NULL,
    household_id bigint
);


ALTER TABLE public.stocks OWNER TO mavioh;

--
-- Name: stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.stocks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stocks_id_seq OWNER TO mavioh;

--
-- Name: stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.stocks_id_seq OWNED BY public.stocks.id;


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.user_settings (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    notif_peremption boolean DEFAULT true NOT NULL,
    notif_rappel_repas boolean DEFAULT false NOT NULL,
    notif_rappel_sport boolean DEFAULT false NOT NULL,
    heure_rappel time(0) without time zone,
    jours_alerte_peremption smallint DEFAULT '3'::smallint NOT NULL,
    unites character varying(16) DEFAULT 'metrique'::character varying NOT NULL,
    theme character varying(16) DEFAULT 'systeme'::character varying NOT NULL,
    langue character varying(8) DEFAULT 'fr'::character varying NOT NULL,
    timezone character varying(64) DEFAULT 'Europe/Paris'::character varying NOT NULL,
    ia_seances boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.user_settings OWNER TO mavioh;

--
-- Name: user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.user_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_settings_id_seq OWNER TO mavioh;

--
-- Name: user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.user_settings_id_seq OWNED BY public.user_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    household_id bigint,
    consentement_sante_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO mavioh;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO mavioh;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: weight_logs; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.weight_logs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    weight_kg numeric(6,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.weight_logs OWNER TO mavioh;

--
-- Name: weight_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.weight_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.weight_logs_id_seq OWNER TO mavioh;

--
-- Name: weight_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.weight_logs_id_seq OWNED BY public.weight_logs.id;


--
-- Name: workout_exercises; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.workout_exercises (
    id bigint NOT NULL,
    session_id bigint NOT NULL,
    exercise_id bigint,
    block character varying(32) DEFAULT 'principal'::character varying NOT NULL,
    "position" smallint DEFAULT '0'::smallint NOT NULL,
    name character varying(255) NOT NULL,
    sets smallint,
    reps smallint,
    duration_sec smallint,
    weight_kg numeric(5,1),
    rest_sec smallint,
    met numeric(4,1),
    completed boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.workout_exercises OWNER TO mavioh;

--
-- Name: workout_exercises_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.workout_exercises_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workout_exercises_id_seq OWNER TO mavioh;

--
-- Name: workout_exercises_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.workout_exercises_id_seq OWNED BY public.workout_exercises.id;


--
-- Name: workout_sessions; Type: TABLE; Schema: public; Owner: mavioh
--

CREATE TABLE public.workout_sessions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    date date NOT NULL,
    planned_at time(0) without time zone,
    title character varying(255) NOT NULL,
    kind character varying(16) DEFAULT 'seance'::character varying NOT NULL,
    goal character varying(32),
    level character varying(16),
    equipment json,
    focus json,
    duration_min smallint NOT NULL,
    calories_burned numeric(7,1),
    status character varying(16) DEFAULT 'prevue'::character varying NOT NULL,
    rpe smallint,
    notes text,
    source character varying(16) DEFAULT 'manuelle'::character varying NOT NULL,
    intensity character varying(16),
    distance_km numeric(6,2),
    started_at timestamp(0) without time zone,
    completed_at timestamp(0) without time zone,
    sport_id bigint,
    sport_name character varying(80),
    lieu character varying(16),
    calories_source character varying(8) DEFAULT 'auto'::character varying NOT NULL,
    generated_by character varying(8),
    llm_model character varying(64),
    sport_plan_id bigint,
    zones_a_eviter json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.workout_sessions OWNER TO mavioh;

--
-- Name: workout_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: mavioh
--

CREATE SEQUENCE public.workout_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workout_sessions_id_seq OWNER TO mavioh;

--
-- Name: workout_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mavioh
--

ALTER SEQUENCE public.workout_sessions_id_seq OWNED BY public.workout_sessions.id;


--
-- Name: daily_targets id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.daily_targets ALTER COLUMN id SET DEFAULT nextval('public.daily_targets_id_seq'::regclass);


--
-- Name: exercises id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.exercises ALTER COLUMN id SET DEFAULT nextval('public.exercises_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: food id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food ALTER COLUMN id SET DEFAULT nextval('public.food_id_seq'::regclass);


--
-- Name: household_members id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.household_members ALTER COLUMN id SET DEFAULT nextval('public.household_members_id_seq'::regclass);


--
-- Name: households id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.households ALTER COLUMN id SET DEFAULT nextval('public.households_id_seq'::regclass);


--
-- Name: meal_items id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items ALTER COLUMN id SET DEFAULT nextval('public.meal_items_id_seq'::regclass);


--
-- Name: meal_plans id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans ALTER COLUMN id SET DEFAULT nextval('public.meal_plans_id_seq'::regclass);


--
-- Name: meals id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meals ALTER COLUMN id SET DEFAULT nextval('public.meals_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: profiles id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.profiles ALTER COLUMN id SET DEFAULT nextval('public.profiles_id_seq'::regclass);


--
-- Name: recipes id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recipes ALTER COLUMN id SET DEFAULT nextval('public.recipes_id_seq'::regclass);


--
-- Name: recommendations id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recommendations ALTER COLUMN id SET DEFAULT nextval('public.recommendations_id_seq'::regclass);


--
-- Name: shopping_items id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.shopping_items ALTER COLUMN id SET DEFAULT nextval('public.shopping_items_id_seq'::regclass);


--
-- Name: sport_plans id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sport_plans ALTER COLUMN id SET DEFAULT nextval('public.sport_plans_id_seq'::regclass);


--
-- Name: sports id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sports ALTER COLUMN id SET DEFAULT nextval('public.sports_id_seq'::regclass);


--
-- Name: stock_items id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stock_items ALTER COLUMN id SET DEFAULT nextval('public.stock_items_id_seq'::regclass);


--
-- Name: stocks id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stocks ALTER COLUMN id SET DEFAULT nextval('public.stocks_id_seq'::regclass);


--
-- Name: user_settings id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.user_settings ALTER COLUMN id SET DEFAULT nextval('public.user_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: weight_logs id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.weight_logs ALTER COLUMN id SET DEFAULT nextval('public.weight_logs_id_seq'::regclass);


--
-- Name: workout_exercises id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_exercises ALTER COLUMN id SET DEFAULT nextval('public.workout_exercises_id_seq'::regclass);


--
-- Name: workout_sessions id; Type: DEFAULT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_sessions ALTER COLUMN id SET DEFAULT nextval('public.workout_sessions_id_seq'::regclass);


--
-- Data for Name: daily_targets; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.daily_targets (id, user_id, date, calories, proteins, carbs, fat, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exercises; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.exercises (id, name, slug, category, muscle_group, equipment, level, met, default_sets, default_reps, default_duration_sec, instructions, contraindications, is_public, created_by_user_id, created_at, updated_at) FROM stdin;
7	Pistol squat assisté	pistol-squat-assiste	force	jambes	aucun	avance	6.0	3	6	\N	Tiens-toi à un support, lève une jambe devant toi et descends sur l’autre jambe le plus bas possible. Remonte en poussant dans le talon.	["genoux","chevilles","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
8	Mollets debout	mollets-debout	force	jambes	aucun	debutant	3.0	3	20	\N	Debout, monte sur la pointe des pieds le plus haut possible puis redescends lentement. Tiens-toi à un mur si besoin.	["chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
26	Écarté couché haltères	ecarte-couche-halteres	force	pectoraux	halteres	intermediaire	4.0	3	12	\N	Bras presque tendus au-dessus de la poitrine, ouvre-les sur les côtés en arc de cercle sans descendre sous le niveau des épaules, puis referme.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
27	Développé couché barre	developpe-couche-barre	force	pectoraux	barre	avance	6.0	4	6	\N	Barre saisie un peu plus large que les épaules, descends-la vers le bas de la poitrine en contrôlant, puis pousse. Omoplates serrées, pieds ancrés.	["epaules","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
36	Extension triceps nuque	extension-triceps-nuque	force	bras	halteres	intermediaire	4.0	3	12	\N	Un haltère tenu à deux mains au-dessus de la tête, fléchis les coudes pour descendre derrière la nuque puis tends les bras.	["coudes","epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
37	Kickback triceps	kickback-triceps	force	bras	halteres	debutant	3.5	3	12	\N	Buste penché, coude fixé le long du corps, tends l’avant-bras vers l’arrière jusqu’à aligner le bras. Reviens lentement.	["coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
38	Rowing haltère un bras	rowing-haltere-un-bras	force	dos	halteres	debutant	4.5	3	12	\N	Une main en appui sur un banc, tire l’haltère vers la hanche en gardant le dos plat et le coude près du corps. Redescends lentement.	["dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
39	Rowing barre	rowing-barre	force	dos	barre	avance	6.0	4	8	\N	Buste penché à 45°, dos plat, tire la barre vers le bas du ventre en serrant les omoplates. Redescends sans arrondir le dos.	["dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
9	Pont fessier	pont-fessier	force	fessiers	aucun	debutant	3.0	3	15	\N	Allongé sur le dos, pieds à plat, soulève le bassin en serrant les fessiers jusqu’à aligner épaules, hanches et genoux. Redescends sans toucher le sol.	["cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
10	Pont fessier unilatéral	pont-fessier-unilateral	force	fessiers	aucun	intermediaire	3.5	3	10	\N	Même position que le pont fessier, mais une jambe tendue en l’air. Pousse dans le talon au sol pour monter le bassin sans le laisser basculer.	["cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
11	Pompes	pompes	force	pectoraux	aucun	debutant	4.0	3	10	\N	Mains sous les épaules, corps aligné de la tête aux talons. Descends la poitrine vers le sol en gardant les coudes à 45°, puis pousse.	["epaules","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
12	Pompes sur les genoux	pompes-genoux	force	pectoraux	aucun	debutant	3.5	3	10	\N	Genoux au sol, mains sous les épaules, gaine le ventre. Descends la poitrine vers le sol puis remonte en poussant fort.	["epaules","poignets","genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
51	Tirage horizontal machine	tirage-horizontal-machine	force	dos	machine	debutant	4.5	3	12	\N	Assis, dos droit, tire la poignée vers le ventre en gardant les coudes près du corps. Reviens en tendant les bras sans arrondir le dos.	["dos","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
52	Développé assis machine	developpe-assis-machine	force	pectoraux	machine	debutant	4.5	3	12	\N	Assis, poignées au niveau de la poitrine, pousse vers l’avant jusqu’à tendre les bras puis reviens lentement.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
53	Développé épaules machine	developpe-epaules-machine	force	epaules	machine	debutant	4.5	3	12	\N	Assis, poignées à hauteur d’épaules, pousse au-dessus de la tête sans cambrer. Redescends jusqu’aux oreilles.	["epaules","cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
54	Tractions	tractions	force	dos	barre_traction	avance	6.5	4	6	\N	Suspendu à la barre en prise pronation, tire-toi jusqu’à passer le menton au-dessus de la barre en serrant les omoplates. Redescends en contrôlant.	["epaules","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
67	Talons-fesses	talons-fesses	cardio	cardio	aucun	debutant	7.0	\N	\N	40	Cours sur place en ramenant les talons vers les fesses, buste droit. Reste léger sur l’avant du pied.	["genoux","chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
68	Pas chassés	pas-chasses	cardio	cardio	aucun	debutant	6.0	\N	\N	40	Déplace-toi latéralement en petits sauts, genoux fléchis, puis change de sens. Reste bas et dynamique.	["genoux","chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
69	Marche sur place	marche-sur-place	cardio	cardio	aucun	debutant	3.0	\N	\N	60	Marche sur place en levant bien les genoux et en balançant les bras. Idéal pour s’échauffer en douceur.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
70	Step touch	step-touch	cardio	cardio	aucun	debutant	4.0	\N	\N	60	Fais un pas sur le côté et ramène l’autre pied, puis repars dans l’autre sens en rythme. Ajoute les bras pour monter le cœur.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
71	Mountain climbers	mountain-climbers	cardio	corps_entier	aucun	intermediaire	8.0	\N	\N	40	En position de planche sur les mains, ramène alternativement un genou vers la poitrine à un rythme soutenu. Garde le bassin stable.	["poignets","epaules","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
72	Burpees	burpees	cardio	corps_entier	aucun	avance	10.0	3	10	\N	Descends en squat, pose les mains au sol, lance les pieds en arrière en planche, fais une pompe, reviens en squat et saute bras levés.	["genoux","poignets","epaules","chevilles","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
73	Corde à sauter	corde-a-sauter	cardio	cardio	aucun	intermediaire	10.0	\N	\N	60	Saute à petits bonds sur l’avant des pieds, coudes près du corps, la corde tourne grâce aux poignets. Reste souple à la réception.	["genoux","chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
74	Shadow boxing	shadow-boxing	cardio	corps_entier	aucun	debutant	7.0	\N	\N	60	En garde, enchaîne directs et crochets dans le vide en te déplaçant sur les appuis. Garde les épaules relâchées et le ventre serré.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
13	Pompes déclinées	pompes-declinees	force	pectoraux	aucun	intermediaire	4.5	3	10	\N	Pieds surélevés sur une marche, mains au sol. Descends en contrôlant, la tête dans l’axe, puis pousse jusqu’à tendre les bras.	["epaules","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
14	Pompes diamant	pompes-diamant	force	bras	aucun	avance	5.0	3	8	\N	Mains jointes sous la poitrine en forme de losange. Descends coudes serrés le long du corps puis pousse : les triceps travaillent fort.	["epaules","poignets","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
15	Dips sur chaise	dips-chaise	force	bras	aucun	intermediaire	4.5	3	10	\N	Mains au bord d’une chaise stable derrière toi, jambes tendues devant. Fléchis les coudes pour descendre les fesses puis pousse.	["epaules","coudes","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
16	Superman	superman	force	dos	aucun	debutant	3.0	3	12	\N	Allongé sur le ventre, décolle simultanément bras et jambes de quelques centimètres en regardant le sol. Tiens une seconde puis relâche.	["dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
17	Crunch	crunch	force	abdos	aucun	debutant	3.0	3	15	\N	Sur le dos, genoux fléchis, décolle les épaules du sol en enroulant le haut du dos, menton légèrement rentré. Redescends lentement.	["cou","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
18	Crunch bicyclette	crunch-bicyclette	force	abdos	aucun	intermediaire	4.0	3	20	\N	Sur le dos, mains aux tempes, amène le coude vers le genou opposé en alternant, comme un pédalage. Garde le bas du dos au sol.	["cou","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
19	Relevé de jambes allongé	releve-de-jambes	force	abdos	aucun	intermediaire	3.5	3	12	\N	Sur le dos, jambes tendues, monte-les à la verticale puis redescends sans toucher le sol. Plaque le bas du dos au tapis.	["dos","cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
20	Squat sauté	squat-saute	cardio	jambes	aucun	intermediaire	8.0	3	10	\N	Descends en squat puis explose vers le haut. Amortis l’atterrissage sur l’avant des pieds en refléchissant les genoux.	["genoux","chevilles","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
21	Fentes sautées	fentes-sautees	cardio	jambes	aucun	avance	9.0	3	10	\N	En position de fente, saute et change de jambe en l’air pour atterrir en fente inversée. Amortis chaque réception.	["genoux","chevilles","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
22	Step-up sur banc	step-up-banc	force	jambes	banc	debutant	5.0	3	12	\N	Pose un pied entier sur le banc et monte en poussant dans le talon, sans t’aider de la jambe arrière. Redescends en contrôlant.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
76	Marche rapide sur tapis	marche-rapide-tapis	cardio	cardio	tapis	debutant	4.5	\N	\N	600	Marche d’un bon pas (5–6 km/h) en balançant les bras, sans tenir les poignées. Redresse-toi et regarde loin.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
101	Mobilité des chevilles	mobilite-chevilles	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	En fente courte, avance le genou vers l’avant au-dessus du pied sans décoller le talon, puis reviens. Fais aussi des cercles de chevilles.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
102	Cercles de poignets et chevilles	cercles-poignets-chevilles	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Dessine des cercles lents avec les poignets dans les deux sens, puis avec chaque cheville. Idéal avant les appuis au sol.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
103	Posture de l’enfant	posture-enfant	mobilite	mobilite	aucun	debutant	2.5	\N	\N	60	À genoux, assieds-toi sur les talons et allonge les bras devant toi, front vers le sol. Respire profondément et relâche le dos.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
1	Squat au poids du corps	squat-poids-du-corps	force	jambes	aucun	debutant	5.0	3	12	\N	Pieds largeur d’épaules, descends en poussant les fesses vers l’arrière, genoux dans l’axe des pieds. Remonte en poussant dans les talons, dos droit.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
2	Squat sumo	squat-sumo	force	fessiers	aucun	debutant	5.0	3	12	\N	Pieds très écartés, pointes vers l’extérieur. Descends en gardant le buste droit, puis remonte en serrant les fessiers.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
3	Fentes avant	fentes-avant	force	jambes	aucun	debutant	4.5	3	10	\N	Fais un grand pas en avant et fléchis les deux genoux à 90°, le genou arrière proche du sol. Reviens en poussant sur la jambe avant.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
4	Fentes arrière	fentes-arriere	force	fessiers	aucun	debutant	4.5	3	10	\N	Recule un pied et descends jusqu’à ce que le genou arrière frôle le sol. Reviens en poussant sur le talon avant, buste droit.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
5	Fentes bulgares	fentes-bulgares	force	fessiers	aucun	intermediaire	5.0	3	10	\N	Un pied surélevé derrière toi sur une marche ou une chaise, descends sur la jambe avant en contrôlant. Remonte sans verrouiller le genou.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
6	Chaise contre le mur	chaise-murale	force	jambes	aucun	debutant	3.0	3	\N	40	Dos plaqué au mur, glisse jusqu’à avoir les cuisses parallèles au sol. Tiens la position en respirant calmement.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
23	Hip thrust au banc	hip-thrust-banc	force	fessiers	banc	intermediaire	4.0	3	12	\N	Haut du dos appuyé sur le banc, pieds au sol, pousse le bassin vers le haut jusqu’à l’horizontale en serrant les fessiers. Menton rentré.	["hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
24	Développé couché haltères	developpe-couche-halteres	force	pectoraux	halteres	intermediaire	5.0	3	10	\N	Allongé sur le banc, haltères au niveau de la poitrine, pousse vers le haut jusqu’à tendre les bras puis redescends lentement.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
25	Développé incliné haltères	developpe-incline-halteres	force	pectoraux	halteres	intermediaire	5.0	3	10	\N	Banc incliné à 30–45°, pousse les haltères vers le haut en gardant les poignets au-dessus des coudes. Redescends jusqu’à la poitrine.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
40	Soulevé de terre barre	souleve-de-terre-barre	force	corps_entier	barre	avance	6.0	4	5	\N	Barre contre les tibias, dos plat, pousse le sol avec les jambes et redresse-toi en gardant la barre proche du corps. Verrouille les hanches en haut.	["dos","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
41	Soulevé de terre roumain haltères	souleve-de-terre-roumain-halteres	force	fessiers	halteres	intermediaire	5.0	3	10	\N	Debout, haltères devant les cuisses, pousse les fesses en arrière en gardant les jambes presque tendues et le dos plat. Reviens en serrant les fessiers.	["dos","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
42	Squat barre	squat-barre	force	jambes	barre	avance	6.0	4	6	\N	Barre sur le haut du dos, pieds largeur d’épaules, descends en contrôlant jusqu’à ce que les cuisses soient parallèles au sol. Remonte dos gainé.	["genoux","dos","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
43	Goblet squat	goblet-squat	force	jambes	kettlebell	debutant	5.0	3	12	\N	Kettlebell tenue contre la poitrine, descends en squat en gardant le buste droit et les coudes entre les genoux. Remonte en poussant dans les talons.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
44	Kettlebell swing	kettlebell-swing	force	corps_entier	kettlebell	intermediaire	8.0	3	15	\N	Balance la kettlebell entre les jambes puis propulse-la à hauteur de poitrine par une extension explosive des hanches. Les bras restent détendus.	["dos","hanches","epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
45	Fentes marchées haltères	fentes-marchees-halteres	force	jambes	halteres	intermediaire	5.5	3	12	\N	Haltères le long du corps, avance en fentes en fléchissant les deux genoux à 90°. Garde le buste droit et le pas régulier.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
46	Marche du fermier	marche-du-fermier	gainage	corps_entier	kettlebell	intermediaire	5.0	3	\N	40	Une charge dans chaque main, marche d’un pas régulier en restant grand, épaules basses et ventre serré. Ne penche pas.	["dos","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
47	Presse à cuisses	presse-a-cuisses	force	jambes	machine	debutant	4.5	3	12	\N	Pieds largeur d’épaules sur la plateforme, descends jusqu’à 90° sans décoller le bas du dos, puis pousse sans verrouiller les genoux.	["genoux","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
28	Développé militaire haltères	developpe-militaire-halteres	force	epaules	halteres	intermediaire	5.0	3	10	\N	Assis ou debout, haltères au niveau des oreilles, pousse au-dessus de la tête sans cambrer. Redescends jusqu’aux épaules.	["epaules","cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
29	Développé militaire barre	developpe-militaire-barre	force	epaules	barre	avance	6.0	4	6	\N	Debout, barre au niveau des clavicules, gaine fort et pousse la barre au-dessus de la tête en passant près du visage. Redescends lentement.	["epaules","dos","cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
30	Élévations latérales	elevations-laterales	force	epaules	halteres	debutant	3.5	3	12	\N	Haltères le long du corps, monte les bras sur les côtés jusqu’à l’horizontale, coudes légèrement fléchis. Redescends sans balancer.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
31	Élévations frontales	elevations-frontales	force	epaules	halteres	debutant	3.5	3	12	\N	Haltères devant les cuisses, monte-les devant toi jusqu’à la hauteur des yeux en alternant ou ensemble. Contrôle la descente.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
32	Oiseau haltères	oiseau-halteres	force	epaules	halteres	intermediaire	4.0	3	12	\N	Buste penché vers l’avant, dos plat, ouvre les bras sur les côtés en serrant les omoplates. Haltères légers, mouvement contrôlé.	["epaules","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
33	Curl biceps haltères	curl-biceps-halteres	force	bras	halteres	debutant	3.5	3	12	\N	Coudes collés au corps, monte les haltères vers les épaules en tournant les paumes vers toi. Redescends lentement sans balancer.	["coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
34	Curl marteau	curl-marteau	force	bras	halteres	debutant	3.5	3	12	\N	Paumes face à face comme si tu tenais un marteau, fléchis les coudes pour monter les haltères. Poignets neutres, coudes fixes.	["coudes","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
35	Curl biceps barre	curl-biceps-barre	force	bras	barre	intermediaire	4.0	3	10	\N	Barre en prise supination, coudes près du corps, monte la barre vers la poitrine puis redescends en contrôlant. Ne cambre pas.	["coudes","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
48	Leg curl machine	leg-curl-machine	force	jambes	machine	debutant	3.5	3	12	\N	Allongé ou assis selon la machine, fléchis les genoux pour ramener le coussin vers les fesses puis reviens lentement.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
49	Leg extension machine	leg-extension-machine	force	jambes	machine	debutant	3.5	3	12	\N	Assis, tends les jambes contre le coussin jusqu’à l’horizontale sans à-coup, puis redescends en contrôlant.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
50	Tirage vertical machine	tirage-vertical-machine	force	dos	machine	debutant	4.5	3	12	\N	Assis, tire la barre vers le haut de la poitrine en abaissant les coudes et en serrant les omoplates. Remonte lentement.	["epaules","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
75	Course sur tapis	course-tapis	cardio	cardio	tapis	intermediaire	9.0	\N	\N	600	Cours à une allure où tu peux encore prononcer quelques mots. Regarde devant toi, foulée légère, bras détendus.	["genoux","chevilles","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
77	Marche inclinée sur tapis	marche-inclinee-tapis	cardio	cardio	tapis	debutant	6.0	\N	\N	600	Règle une pente de 6 à 10 % et marche d’un pas régulier sans te tenir. Les mollets et les fessiers travaillent davantage.	["chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
78	Vélo d’appartement	velo-appartement	cardio	cardio	velo	debutant	6.5	\N	\N	600	Selle à hauteur de hanche, pédale à une cadence régulière (80–90 tr/min) avec une résistance qui te laisse parler.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
79	Fractionné vélo	fractionne-velo	cardio	cardio	velo	intermediaire	8.5	\N	\N	480	Alterne 30 secondes rapides avec résistance et 60 secondes de récupération souple. Reste assis et garde le haut du corps stable.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
80	Planche	planche	gainage	abdos	aucun	debutant	3.0	3	\N	30	En appui sur les avant-bras et les pointes de pieds, aligne épaules, bassin et talons. Serre le ventre et les fessiers, respire.	["epaules","poignets","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
81	Planche latérale	planche-laterale	gainage	abdos	aucun	intermediaire	3.0	3	\N	20	Sur le côté, en appui sur l’avant-bras et le bord du pied, décolle le bassin pour aligner le corps. Tiens puis change de côté.	["epaules","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
82	Planche avec toucher d’épaule	planche-toucher-epaule	gainage	abdos	aucun	intermediaire	3.5	3	12	\N	En planche sur les mains, touche l’épaule opposée avec une main en gardant le bassin immobile, puis alterne.	["poignets","epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
91	Rotation thoracique à quatre pattes	rotation-thoracique	mobilite	mobilite	aucun	debutant	2.5	3	8	\N	À quatre pattes, une main derrière la tête, ouvre le coude vers le plafond en tournant le haut du dos, puis reviens. Alterne les côtés.	["poignets","genoux","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
55	Tractions australiennes	tractions-australiennes	force	dos	barre_traction	intermediaire	5.0	3	10	\N	Barre basse, corps incliné sous la barre et gainé, tire la poitrine vers la barre puis redescends lentement.	["epaules","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
56	Suspension à la barre	suspension-barre	gainage	dos	barre_traction	debutant	3.0	3	\N	20	Suspends-toi à la barre bras tendus, épaules actives (légèrement tirées vers le bas), et tiens la position en respirant.	["epaules","poignets"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
57	Squat élastique	squat-elastique	force	jambes	elastiques	debutant	4.5	3	15	\N	Élastique sous les pieds et sur les épaules, descends en squat puis remonte contre la résistance. Genoux dans l’axe des pieds.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
58	Rowing élastique	rowing-elastique	force	dos	elastiques	debutant	4.0	3	15	\N	Assis jambes tendues, élastique autour des pieds, tire les poignées vers le ventre en serrant les omoplates. Reviens lentement.	["dos","coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
59	Face pull élastique	face-pull-elastique	force	epaules	elastiques	debutant	3.5	3	15	\N	Élastique fixé à hauteur du visage, tire vers toi en écartant les mains au niveau des oreilles, coudes hauts. Reviens en contrôlant.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
60	Curl biceps élastique	curl-biceps-elastique	force	bras	elastiques	debutant	3.0	3	15	\N	Élastique sous les pieds, coudes collés au corps, fléchis les bras pour amener les poignées vers les épaules. Redescends lentement.	["coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
61	Extension triceps élastique	extension-triceps-elastique	force	bras	elastiques	debutant	3.0	3	15	\N	Élastique fixé en hauteur, coudes près du corps, tends les avant-bras vers le bas puis reviens sans bouger les coudes.	["coudes"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
62	Abduction de hanche élastique	abduction-hanche-elastique	force	fessiers	elastiques	debutant	3.0	3	15	\N	Élastique autour des chevilles ou des genoux, écarte une jambe sur le côté sans pencher le buste. Reviens lentement.	["hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
63	Pont fessier élastique	pont-fessier-elastique	force	fessiers	elastiques	debutant	3.5	3	15	\N	Élastique au-dessus des genoux, allongé sur le dos, monte le bassin en poussant les genoux vers l’extérieur. Redescends sans toucher le sol.	["cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
64	Développé élastique	developpe-elastique	force	pectoraux	elastiques	debutant	3.5	3	15	\N	Élastique passé dans le dos, pousse les poignées vers l’avant jusqu’à tendre les bras, puis reviens en contrôlant.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
65	Jumping jacks	jumping-jacks	cardio	cardio	aucun	debutant	8.0	\N	\N	40	Saute en écartant les jambes et en levant les bras au-dessus de la tête, puis reviens pieds joints. Garde un rythme régulier.	["genoux","chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
66	Montées de genoux	montees-de-genoux	cardio	cardio	aucun	debutant	8.0	\N	\N	40	Cours sur place en montant les genoux à hauteur des hanches, buste droit, bras qui accompagnent. Adapte la vitesse à ton souffle.	["genoux","chevilles","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
93	Le plus grand étirement du monde	plus-grand-etirement-du-monde	mobilite	corps_entier	aucun	intermediaire	3.0	3	6	\N	Depuis une fente, pose la main opposée au sol, tourne le buste et lève l’autre bras vers le plafond, puis reviens. Alterne.	["poignets","genoux","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
94	Ouverture de hanches 90/90	ouverture-hanches-90-90	mobilite	mobilite	aucun	intermediaire	2.5	\N	\N	60	Assis, une jambe pliée devant à 90° et l’autre sur le côté à 90°. Penche le buste vers la jambe avant, dos long, puis change de côté.	["hanches","genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
83	Hollow hold	hollow-hold	gainage	abdos	aucun	intermediaire	3.0	3	\N	20	Sur le dos, bras tendus derrière la tête et jambes tendues, décolle épaules et jambes en plaquant le bas du dos au sol. Tiens la position.	["dos","cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
84	Dead bug	dead-bug	gainage	abdos	aucun	debutant	2.5	3	10	\N	Sur le dos, bras vers le plafond et genoux à 90°, étends lentement un bras et la jambe opposée sans décoller le bas du dos. Alterne.	["cou"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
85	Bird dog	bird-dog	gainage	dos	aucun	debutant	2.5	3	10	\N	À quatre pattes, tends simultanément un bras devant et la jambe opposée derrière sans bouger le bassin. Reviens et alterne.	["poignets","genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
86	Planche inversée	planche-inversee	gainage	dos	aucun	intermediaire	3.0	3	\N	20	Assis, mains au sol derrière toi doigts vers les pieds, soulève le bassin jusqu’à aligner le corps. Regarde le plafond et serre les fessiers.	["epaules","poignets","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
87	Pallof press élastique	pallof-press-elastique	gainage	abdos	elastiques	intermediaire	3.0	3	10	\N	Élastique fixé sur le côté à hauteur de poitrine, tends les bras devant toi puis reviens sans laisser le buste tourner. Change de côté.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
88	Chat-vache	chat-vache	mobilite	mobilite	aucun	debutant	2.5	\N	\N	60	À quatre pattes, arrondis le dos en rentrant le menton (chat) puis creuse-le en regardant devant (vache). Enchaîne lentement avec la respiration.	["poignets","genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
89	Cercles de bras	cercles-de-bras	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Debout, fais de grands cercles avec les bras vers l’avant puis vers l’arrière, en augmentant progressivement l’amplitude.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
90	Rotations du bassin	rotations-bassin	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Mains sur les hanches, dessine de grands cercles avec le bassin dans un sens puis dans l’autre. Garde les genoux souples.	[]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
92	Fente avec rotation du buste	fente-rotation-buste	mobilite	mobilite	aucun	intermediaire	3.0	3	8	\N	En fente avant basse, tourne le buste vers la jambe avant en ouvrant les bras, puis reviens. Alterne les côtés.	["genoux","dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
95	Balancements de jambes	balancements-de-jambes	mobilite	mobilite	aucun	debutant	3.0	\N	\N	40	Tiens-toi à un support et balance une jambe d’avant en arrière en amplitude croissante, puis latéralement. Change de jambe.	["hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
96	Étirement des ischio-jambiers	etirement-ischios	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Une jambe tendue devant, talon au sol, penche le buste vers l’avant dos plat jusqu’à sentir l’arrière de la cuisse. Respire, puis change.	["dos"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
97	Étirement des quadriceps debout	etirement-quadriceps	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Debout, attrape un pied derrière toi et ramène le talon vers la fesse, genoux proches. Tiens-toi à un mur si besoin, puis change.	["genoux"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
98	Étirement du psoas	etirement-psoas	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Genou arrière au sol en fente, avance le bassin vers l’avant en gardant le buste droit jusqu’à sentir l’avant de la hanche. Change de côté.	["genoux","hanches"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
99	Étirement des mollets au mur	etirement-mollets	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Mains au mur, une jambe tendue en arrière talon au sol, avance le bassin jusqu’à sentir le mollet. Tiens puis change de jambe.	["chevilles"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
100	Étirement des pectoraux au mur	etirement-pectoraux-mur	mobilite	mobilite	aucun	debutant	2.5	\N	\N	40	Avant-bras contre un mur ou un cadre de porte, coude à hauteur d’épaule, tourne doucement le buste dans l’autre sens. Change de côté.	["epaules"]	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: food; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.food (id, created_at, updated_at, barcode, name, brand, image_url, calories, fat, carbs, proteins, source_type, created_by_user_id, serving_size_g, serving_label, category, allergens, fiber, sugar, salt, density_g_per_ml, per_unit, source_fetched_at, off_last_checked_at, is_verified) FROM stdin;
\.


--
-- Data for Name: food_favorites; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.food_favorites (user_id, food_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: household_members; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.household_members (id, household_id, user_id, role, share_profile, joined_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.households (id, name, owner_id, invite_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meal_items; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.meal_items (id, meal_id, food_id, recipe_id, stock_item_id, source_type, label, quantity, unit, grams_equivalent, calories, proteins, carbs, fat, fiber, sugar, salt, ref_basis, ref_calories, ref_proteins, ref_carbs, ref_fat, ref_fiber, ref_sugar, ref_salt, ref_serving_size_g, is_estimate, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meal_plans; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.meal_plans (id, user_id, household_id, date, meal_type, recipe_id, food_id, title, servings, notes, status, meal_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: meals; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.meals (id, user_id, date, type, name, consumed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2026_04_13_163541_create_food_table	1
6	2026_04_13_163541_create_meals_table	1
7	2026_04_13_163541_create_profiles_table	1
8	2026_04_13_163542_create_families_table	1
9	2026_04_13_163542_create_family_members_table	1
10	2026_04_13_163542_create_meal_items_table	1
11	2026_04_13_163542_create_stock_items_table	1
12	2026_04_13_163542_create_stocks_table	1
13	2026_04_17_180000_add_user_fields_to_profiles_table	1
14	2026_04_17_181500_add_planning_fields_to_profiles_table	1
15	2026_04_17_190000_add_target_goal_fields_to_profiles_table	1
16	2026_04_17_200000_add_catalog_fields_to_food_table	1
17	2026_04_17_210000_add_creator_to_food_table	1
18	2026_04_17_230000_add_fridge_fields_to_stocks_tables	1
19	2026_04_17_231000_make_stocks_multi_locations	1
20	2026_04_17_233000_create_recipes_table	1
21	2026_04_17_234000_expand_recipe_image_url	1
22	2026_04_18_130000_alter_recipes_image_url_to_text	1
23	2026_09_16_000005_alter_food_for_off	1
24	2026_09_16_000010_rebuild_meals_tables	1
25	2026_09_16_000020_drop_legacy_family_tables	1
26	2026_09_16_000030_create_households_table	1
27	2026_09_16_000031_create_household_members_table	1
28	2026_09_16_000040_add_household_id_to_users_table	1
29	2026_09_16_000045_add_consent_to_users_table	1
30	2026_09_16_000050_add_household_scope_to_stocks	1
31	2026_09_16_000060_extend_profiles_table	1
32	2026_09_16_000070_extend_recipes_table	1
33	2026_09_16_000080_extend_stock_items_table	1
34	2026_09_16_000090_create_weight_logs_table	1
35	2026_09_16_000095_create_daily_targets_table	1
36	2026_09_16_000100_create_shopping_items_table	1
37	2026_09_16_000110_create_meal_plans_table	1
38	2026_09_16_000120_create_recommendations_table	1
39	2026_09_16_000130_create_exercises_table	1
40	2026_09_16_000135_create_sports_table	1
41	2026_09_16_000140_create_workout_sessions_table	1
42	2026_09_16_000141_create_workout_exercises_table	1
43	2026_09_16_000142_create_sport_plans_table	1
44	2026_09_16_000150_create_user_settings_table	1
45	2026_09_16_000160_create_notification_reads_table	1
\.


--
-- Data for Name: notification_reads; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.notification_reads (user_id, key, read_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
1	App\\Models\\User	1	auth_token	2249ff96b6217984a359d94809cf2761f4f9c083596c95fb65173c0b8e18f8e4	["*"]	2026-09-23 11:11:41	\N	2026-09-23 10:45:19	2026-09-23 11:11:41
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.profiles (id, created_at, updated_at, user_id, poids, taille, age, sexe, objectif, niveau_activite, poids_a_perdre_kg, delai_objectif_semaines, bien_etre, calories_cibles, proteines_cibles, glucides_cibles, lipides_cibles, regime_alimentaire, poids_souhaite_kg, delai_objectif_jours, objectif_type, allergenes, aliments_exclus, preferences, sport_niveau, sport_objectif, sport_materiel, sport_temps_dispo_min, sport_jours_semaine, sport_lieu, sport_zones_a_eviter, sport_focus, sport_notes, sport_coef_calories, objectif_calcul_auto, objectif_date_debut, objectif_date_fin, poids_reference, cibles_calculees_le, situation_particuliere, consentement_parental) FROM stdin;
1	2026-09-23 11:04:34	2026-09-23 11:04:34	1	120.00	180.00	21	homme	perdre	sedentaire	\N	\N	\N	2285	192	220	71	omnivore	90.00	600	perdre	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	100	f	2026-09-23	2028-05-15	\N	\N	aucune	f
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.recipes (id, created_by_user_id, title, description, prep_time_minutes, calories, image_url, ingredients, is_public, created_at, updated_at, servings, proteins, carbs, fat, tags, meal_types, is_estimate) FROM stdin;
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.recommendations (id, user_id, date, type, dedupe_key, title, message, factors, actions, priority, status, is_estimate, created_at, updated_at) FROM stdin;
3	1	2026-09-22	profil_incomplet	0f7e798250cefbaed867e120c98730d0ba9af577	Complète ton profil	Complète ton profil pour obtenir tes objectifs personnalisés.	[]	[]	1	new	f	2026-09-23 10:46:44	2026-09-23 10:46:44
5	1	2026-09-23	suggestion_repas	88565aacb64f10dea269d7a37a1951b3ebe530e6	Idée pour ton déjeuner	Pour ton déjeuner (≈ 800 kcal), une idée simple : Bowl de quinoa, pois chiches rôtis et avocat (≈ 590 kcal).	[{"label":"meal_type","value":"dejeuner"},{"label":"budget_repas","value":800,"unit":"kcal"},{"label":"fenetre_kcal_min","value":480,"unit":"kcal"},{"label":"fenetre_kcal_max","value":880,"unit":"kcal"},{"label":"calories_restantes","value":2285,"unit":"kcal"},{"label":"kcal_idee","value":590,"unit":"kcal"}]	[]	2	new	t	2026-09-23 11:04:40	2026-09-23 11:04:40
\.


--
-- Data for Name: shopping_items; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.shopping_items (id, user_id, household_id, food_id, label, quantity, unit, checked, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sport_plans; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.sport_plans (id, user_id, date, sport_id, sport_name, planned_duration_min, planned_at, lieu, notes, status, session_id, recurrence_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sports; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.sports (id, name, slug, category, met_faible, met_moderee, met_elevee, icon, is_public, created_by_user_id, created_at, updated_at) FROM stdin;
1	Course à pied	course-a-pied	endurance	8.0	9.8	11.5	directions_run	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
2	Marche	marche	endurance	3.0	3.5	4.3	directions_walk	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
3	Marche nordique	marche-nordique	endurance	4.5	5.5	6.5	hiking	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
4	Randonnée	randonnee	endurance	5.0	6.0	7.5	hiking	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
5	Trail	trail	endurance	8.0	10.0	12.0	terrain	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
6	Vélo	velo	endurance	5.8	7.5	10.0	directions_bike	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
26	Handball	handball	collectif	7.0	8.5	10.0	sports_handball	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
27	Volley-ball	volley-ball	collectif	3.0	4.0	6.0	sports_volleyball	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
28	Rugby	rugby	collectif	7.0	8.3	10.0	sports_rugby	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
29	Tennis	tennis	raquette	5.0	7.3	8.0	sports_tennis	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
30	Padel	padel	raquette	5.0	6.5	8.0	sports_tennis	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
31	Badminton	badminton	raquette	4.5	5.5	7.0	sports_tennis	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
32	Tennis de table	tennis-de-table	raquette	3.0	4.0	5.0	sports_tennis	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
33	Squash	squash	raquette	7.0	9.0	11.0	sports_tennis	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
34	Boxe	boxe	combat	6.0	8.0	12.0	sports_mma	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
35	Arts martiaux	arts-martiaux	combat	5.5	8.0	10.3	sports_martial_arts	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
36	Ski alpin	ski-alpin	glisse	4.5	5.5	7.0	downhill_skiing	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
37	Ski de fond	ski-de-fond	glisse	7.0	9.0	12.0	nordic_walking	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
38	Skate	skate	glisse	5.0	6.0	7.0	skateboarding	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
39	Danse	danse	autre	3.5	5.5	7.5	music_note	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
40	Zumba	zumba	autre	5.0	6.5	8.0	music_note	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
41	Golf	golf	autre	3.5	4.5	5.5	sports_golf	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
42	Équitation	equitation	autre	3.5	5.5	7.0	bedroom_baby	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
43	Autre	autre	autre	4.0	6.0	8.0	sports	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
7	VTT	vtt	endurance	6.5	8.5	10.5	pedal_bike	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
8	Rameur	rameur	endurance	4.8	7.0	8.5	rowing	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
9	Elliptique	elliptique	endurance	4.5	5.5	7.0	fitness_center	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
10	Corde à sauter	corde-a-sauter	endurance	8.8	11.0	12.3	sports_gymnastics	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
11	Trottinette	trottinette	endurance	4.0	5.0	6.0	electric_scooter	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
12	Roller	roller	glisse	6.0	7.5	9.5	roller_skating	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
13	Musculation	musculation	force	3.5	5.0	6.0	fitness_center	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
14	CrossFit	crossfit	force	6.0	8.0	10.0	fitness_center	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
15	HIIT	hiit	force	7.0	9.0	11.0	bolt	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
16	Escalade	escalade	force	5.0	7.5	9.0	landscape	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
17	Natation	natation	aquatique	6.0	8.0	10.0	pool	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
18	Aquagym	aquagym	aquatique	4.0	5.3	6.5	pool	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
19	Aviron / kayak	aviron-kayak	aquatique	4.0	6.0	8.5	kayaking	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
20	Surf	surf	aquatique	3.0	5.0	6.0	surfing	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
21	Yoga	yoga	bien_etre	2.5	3.0	4.0	self_improvement	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
22	Pilates	pilates	bien_etre	3.0	3.8	4.5	self_improvement	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
23	Stretching	stretching	bien_etre	2.3	2.8	3.3	accessibility_new	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
24	Football	football	collectif	6.0	8.0	10.0	sports_soccer	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
25	Basketball	basketball	collectif	6.0	8.0	9.5	sports_basketball	t	\N	2026-09-23 09:36:52	2026-09-23 11:00:49
\.


--
-- Data for Name: stock_items; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.stock_items (id, created_at, updated_at, stock_id, food_id, food_name, food_barcode, food_brand, quantity, unit, expires_at, min_quantity, opened_at, depleted_at, expiry_kind) FROM stdin;
\.


--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.stocks (id, created_at, updated_at, user_id, name, household_id) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.user_settings (id, user_id, notif_peremption, notif_rappel_repas, notif_rappel_sport, heure_rappel, jours_alerte_peremption, unites, theme, langue, timezone, ia_seances, created_at, updated_at) FROM stdin;
1	1	t	f	f	\N	3	metrique	systeme	fr	Europe/Paris	t	2026-09-23 10:45:19	2026-09-23 10:45:19
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, household_id, consentement_sante_at) FROM stdin;
1	Florent Windels	florentwindels@gmail.com	\N	$2y$12$OeSN2EiBUPk.QX0s51SmleoBygNSOtHr1r9HtlSmAwR9wq0U/kRaa	\N	2026-09-23 10:45:19	2026-09-23 11:04:34	\N	2026-09-23 11:04:34
\.


--
-- Data for Name: weight_logs; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.weight_logs (id, user_id, date, weight_kg, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workout_exercises; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.workout_exercises (id, session_id, exercise_id, block, "position", name, sets, reps, duration_sec, weight_kg, rest_sec, met, completed, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workout_sessions; Type: TABLE DATA; Schema: public; Owner: mavioh
--

COPY public.workout_sessions (id, user_id, date, planned_at, title, kind, goal, level, equipment, focus, duration_min, calories_burned, status, rpe, notes, source, intensity, distance_km, started_at, completed_at, sport_id, sport_name, lieu, calories_source, generated_by, llm_model, sport_plan_id, zones_a_eviter, created_at, updated_at) FROM stdin;
\.


--
-- Name: daily_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.daily_targets_id_seq', 1, false);


--
-- Name: exercises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.exercises_id_seq', 412, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: food_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.food_id_seq', 1, false);


--
-- Name: household_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.household_members_id_seq', 1, false);


--
-- Name: households_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.households_id_seq', 1, false);


--
-- Name: meal_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.meal_items_id_seq', 1, false);


--
-- Name: meal_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.meal_plans_id_seq', 1, false);


--
-- Name: meals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.meals_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.migrations_id_seq', 45, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, true);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.profiles_id_seq', 1, true);


--
-- Name: recipes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.recipes_id_seq', 1, false);


--
-- Name: recommendations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.recommendations_id_seq', 5, true);


--
-- Name: shopping_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.shopping_items_id_seq', 1, false);


--
-- Name: sport_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.sport_plans_id_seq', 1, false);


--
-- Name: sports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.sports_id_seq', 172, true);


--
-- Name: stock_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.stock_items_id_seq', 1, false);


--
-- Name: stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.stocks_id_seq', 1, false);


--
-- Name: user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.user_settings_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: weight_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.weight_logs_id_seq', 1, false);


--
-- Name: workout_exercises_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.workout_exercises_id_seq', 1, false);


--
-- Name: workout_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mavioh
--

SELECT pg_catalog.setval('public.workout_sessions_id_seq', 1, false);


--
-- Name: daily_targets daily_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.daily_targets
    ADD CONSTRAINT daily_targets_pkey PRIMARY KEY (id);


--
-- Name: daily_targets daily_targets_user_id_date_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.daily_targets
    ADD CONSTRAINT daily_targets_user_id_date_unique UNIQUE (user_id, date);


--
-- Name: exercises exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_pkey PRIMARY KEY (id);


--
-- Name: exercises exercises_slug_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.exercises
    ADD CONSTRAINT exercises_slug_unique UNIQUE (slug);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: food food_barcode_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food
    ADD CONSTRAINT food_barcode_unique UNIQUE (barcode);


--
-- Name: food_favorites food_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food_favorites
    ADD CONSTRAINT food_favorites_pkey PRIMARY KEY (user_id, food_id);


--
-- Name: food food_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food
    ADD CONSTRAINT food_pkey PRIMARY KEY (id);


--
-- Name: household_members household_members_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.household_members
    ADD CONSTRAINT household_members_pkey PRIMARY KEY (id);


--
-- Name: household_members household_members_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.household_members
    ADD CONSTRAINT household_members_user_id_unique UNIQUE (user_id);


--
-- Name: households households_invite_code_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_invite_code_unique UNIQUE (invite_code);


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_pkey PRIMARY KEY (id);


--
-- Name: meal_items meal_items_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items
    ADD CONSTRAINT meal_items_pkey PRIMARY KEY (id);


--
-- Name: meal_plans meal_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_pkey PRIMARY KEY (id);


--
-- Name: meals meals_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_pkey PRIMARY KEY (id);


--
-- Name: meals meals_user_id_date_type_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_user_id_date_type_unique UNIQUE (user_id, date, type);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: notification_reads notification_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.notification_reads
    ADD CONSTRAINT notification_reads_pkey PRIMARY KEY (user_id, key);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_unique UNIQUE (user_id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_user_id_date_dedupe_key_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_date_dedupe_key_unique UNIQUE (user_id, date, dedupe_key);


--
-- Name: shopping_items shopping_items_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_pkey PRIMARY KEY (id);


--
-- Name: sport_plans sport_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sport_plans
    ADD CONSTRAINT sport_plans_pkey PRIMARY KEY (id);


--
-- Name: sports sports_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sports
    ADD CONSTRAINT sports_pkey PRIMARY KEY (id);


--
-- Name: sports sports_slug_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sports
    ADD CONSTRAINT sports_slug_unique UNIQUE (slug);


--
-- Name: stock_items stock_items_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_pkey PRIMARY KEY (id);


--
-- Name: stocks stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: user_settings user_settings_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_unique UNIQUE (user_id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: weight_logs weight_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.weight_logs
    ADD CONSTRAINT weight_logs_pkey PRIMARY KEY (id);


--
-- Name: weight_logs weight_logs_user_id_date_unique; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.weight_logs
    ADD CONSTRAINT weight_logs_user_id_date_unique UNIQUE (user_id, date);


--
-- Name: workout_exercises workout_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_exercises
    ADD CONSTRAINT workout_exercises_pkey PRIMARY KEY (id);


--
-- Name: workout_sessions workout_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_pkey PRIMARY KEY (id);


--
-- Name: exercises_category_level_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX exercises_category_level_index ON public.exercises USING btree (category, level);


--
-- Name: exercises_equipment_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX exercises_equipment_index ON public.exercises USING btree (equipment);


--
-- Name: exercises_muscle_group_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX exercises_muscle_group_index ON public.exercises USING btree (muscle_group);


--
-- Name: meal_items_food_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meal_items_food_id_index ON public.meal_items USING btree (food_id);


--
-- Name: meal_items_meal_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meal_items_meal_id_index ON public.meal_items USING btree (meal_id);


--
-- Name: meal_items_recipe_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meal_items_recipe_id_index ON public.meal_items USING btree (recipe_id);


--
-- Name: meal_plans_household_id_date_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meal_plans_household_id_date_index ON public.meal_plans USING btree (household_id, date);


--
-- Name: meal_plans_user_id_date_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meal_plans_user_id_date_index ON public.meal_plans USING btree (user_id, date);


--
-- Name: meals_user_id_date_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX meals_user_id_date_index ON public.meals USING btree (user_id, date);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: recipes_created_by_user_id_is_public_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX recipes_created_by_user_id_is_public_index ON public.recipes USING btree (created_by_user_id, is_public);


--
-- Name: shopping_items_household_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX shopping_items_household_id_index ON public.shopping_items USING btree (household_id);


--
-- Name: shopping_items_user_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX shopping_items_user_id_index ON public.shopping_items USING btree (user_id);


--
-- Name: sport_plans_recurrence_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX sport_plans_recurrence_id_index ON public.sport_plans USING btree (recurrence_id);


--
-- Name: sport_plans_user_id_date_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX sport_plans_user_id_date_index ON public.sport_plans USING btree (user_id, date);


--
-- Name: sports_category_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX sports_category_index ON public.sports USING btree (category);


--
-- Name: sports_created_by_user_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX sports_created_by_user_id_index ON public.sports USING btree (created_by_user_id);


--
-- Name: stock_items_expires_at_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX stock_items_expires_at_index ON public.stock_items USING btree (expires_at);


--
-- Name: stock_items_food_barcode_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX stock_items_food_barcode_index ON public.stock_items USING btree (food_barcode);


--
-- Name: stock_items_food_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX stock_items_food_id_index ON public.stock_items USING btree (food_id);


--
-- Name: stock_items_stock_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX stock_items_stock_id_index ON public.stock_items USING btree (stock_id);


--
-- Name: stocks_household_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX stocks_household_id_index ON public.stocks USING btree (household_id);


--
-- Name: stocks_household_name_unique; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE UNIQUE INDEX stocks_household_name_unique ON public.stocks USING btree (household_id, lower((name)::text)) WHERE (household_id IS NOT NULL);


--
-- Name: stocks_user_name_unique; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE UNIQUE INDEX stocks_user_name_unique ON public.stocks USING btree (user_id, lower((name)::text)) WHERE (household_id IS NULL);


--
-- Name: users_household_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX users_household_id_index ON public.users USING btree (household_id);


--
-- Name: workout_exercises_session_id_position_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX workout_exercises_session_id_position_index ON public.workout_exercises USING btree (session_id, "position");


--
-- Name: workout_sessions_sport_plan_id_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX workout_sessions_sport_plan_id_index ON public.workout_sessions USING btree (sport_plan_id);


--
-- Name: workout_sessions_user_id_date_index; Type: INDEX; Schema: public; Owner: mavioh
--

CREATE INDEX workout_sessions_user_id_date_index ON public.workout_sessions USING btree (user_id, date);


--
-- Name: daily_targets daily_targets_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.daily_targets
    ADD CONSTRAINT daily_targets_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: food food_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food
    ADD CONSTRAINT food_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: food_favorites food_favorites_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food_favorites
    ADD CONSTRAINT food_favorites_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.food(id) ON DELETE CASCADE;


--
-- Name: food_favorites food_favorites_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.food_favorites
    ADD CONSTRAINT food_favorites_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: household_members household_members_household_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.household_members
    ADD CONSTRAINT household_members_household_id_foreign FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: household_members household_members_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.household_members
    ADD CONSTRAINT household_members_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: households households_owner_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_owner_id_foreign FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: meal_items meal_items_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items
    ADD CONSTRAINT meal_items_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.food(id) ON DELETE SET NULL;


--
-- Name: meal_items meal_items_meal_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items
    ADD CONSTRAINT meal_items_meal_id_foreign FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE CASCADE;


--
-- Name: meal_items meal_items_recipe_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items
    ADD CONSTRAINT meal_items_recipe_id_foreign FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE SET NULL;


--
-- Name: meal_items meal_items_stock_item_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_items
    ADD CONSTRAINT meal_items_stock_item_id_foreign FOREIGN KEY (stock_item_id) REFERENCES public.stock_items(id) ON DELETE SET NULL;


--
-- Name: meal_plans meal_plans_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.food(id) ON DELETE SET NULL;


--
-- Name: meal_plans meal_plans_meal_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_meal_id_foreign FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE SET NULL;


--
-- Name: meal_plans meal_plans_recipe_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_recipe_id_foreign FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE SET NULL;


--
-- Name: meal_plans meal_plans_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meal_plans
    ADD CONSTRAINT meal_plans_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: meals meals_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notification_reads notification_reads_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.notification_reads
    ADD CONSTRAINT notification_reads_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_created_by_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_created_by_user_id_foreign FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: recommendations recommendations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shopping_items shopping_items_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.food(id) ON DELETE SET NULL;


--
-- Name: sport_plans sport_plans_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sport_plans
    ADD CONSTRAINT sport_plans_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.workout_sessions(id) ON DELETE SET NULL;


--
-- Name: sport_plans sport_plans_sport_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sport_plans
    ADD CONSTRAINT sport_plans_sport_id_foreign FOREIGN KEY (sport_id) REFERENCES public.sports(id) ON DELETE SET NULL;


--
-- Name: sport_plans sport_plans_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.sport_plans
    ADD CONSTRAINT sport_plans_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: stock_items stock_items_food_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_food_id_foreign FOREIGN KEY (food_id) REFERENCES public.food(id) ON DELETE SET NULL;


--
-- Name: stock_items stock_items_stock_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stock_items
    ADD CONSTRAINT stock_items_stock_id_foreign FOREIGN KEY (stock_id) REFERENCES public.stocks(id) ON DELETE CASCADE;


--
-- Name: stocks stocks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_settings user_settings_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: weight_logs weight_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.weight_logs
    ADD CONSTRAINT weight_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_exercises workout_exercises_exercise_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_exercises
    ADD CONSTRAINT workout_exercises_exercise_id_foreign FOREIGN KEY (exercise_id) REFERENCES public.exercises(id) ON DELETE SET NULL;


--
-- Name: workout_exercises workout_exercises_session_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_exercises
    ADD CONSTRAINT workout_exercises_session_id_foreign FOREIGN KEY (session_id) REFERENCES public.workout_sessions(id) ON DELETE CASCADE;


--
-- Name: workout_sessions workout_sessions_sport_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_sport_id_foreign FOREIGN KEY (sport_id) REFERENCES public.sports(id) ON DELETE SET NULL;


--
-- Name: workout_sessions workout_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mavioh
--

ALTER TABLE ONLY public.workout_sessions
    ADD CONSTRAINT workout_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict GnR2hezGlF1kPgsCv1atahcQEHGKWwXc8tdOEQfhq3xSLIbDvRRsiMZfgo85cum

